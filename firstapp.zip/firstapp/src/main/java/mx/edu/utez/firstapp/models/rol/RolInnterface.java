package mx.edu.utez.firstapp.models.rol;

public interface RolInnterface {
}
