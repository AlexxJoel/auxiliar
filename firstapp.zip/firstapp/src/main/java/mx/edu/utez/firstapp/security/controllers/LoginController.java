package mx.edu.utez.firstapp.security.controllers;

public class LoginController {
}
